//
//  PancakeStack.swift
//  ProjectSDBX
//
//  Created by Scotty B on 26/4/21.
//

import Foundation

struct PancakeStack {
    
    public var diffMap: [UInt8] // = Array<UInt8>(repeating: 0x00, count: 256)
    
}
